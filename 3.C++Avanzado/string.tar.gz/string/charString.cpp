#include <iostream>
#include <string>

using namespace std;

int main(){
	
	char *palabra = "hola mundo";
	string palabra2(palabra);

	cout << palabra << endl;

	cout << palabra2 << endl;


	return 0;
}