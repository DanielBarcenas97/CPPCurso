#include <iostream>
#include <string>

using namespace std;

int main(){

	string cadena = "Hola mundo!";

	//Redimensionar una cadena:
	cout << cadena.length() << endl;

	cadena.resize(cadena.length() * 2);

	cout << cadena.length() << endl;

	//Swap:
	string cadena2 = "camara";

	cout << "cadena 1: " << cadena << endl;
	cout << "cadena 2: " << cadena2 << endl;

	cadena.swap(cadena2);

	cout << "cadena 1: " << cadena << endl;
	cout << "cadena 2: " << cadena2 << endl;

	return 0;
}