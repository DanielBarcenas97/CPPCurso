/*
Programa que reciba una cadena:
-verifique si es un palindromo
-Si me dan una cadena vacia, preguntar 'KHE?'
-Si la frase ingresada es "curso de c++ avanzado",
 Repartir la frase en palabras (curso,de,c,avanzado)
*/

#include <iostream>
#include <string>

using namespace std;

int main(){

	string palabra,aux;
	bool palindromo = true;
	int j;
	string curso,de,c,avanzado;

	cout << "Ingresa una palabra: ";
	getline(cin,palabra);
	aux = palabra;
	j = aux.length()-1;

	if(palabra == ""){
		cout << "KHE? >:v" << endl;
	}else if(palabra == "curso de c++ avanzado"){

		//cout << "Entre" << endl;

		curso = palabra.substr(0,5);
		de = palabra.substr(6,2);
		c = palabra.substr(9,3);
		avanzado = palabra.substr(13,8);

		cout << curso << endl;
		cout << de << endl;
		cout << c << endl;
		cout << avanzado << endl;
	}
	else{

	for(int i = 0; i < palabra.length(); i++){
		if(i == j)
			break;
		if(palabra[i] == ' ')
			i++;
		if(aux[j] == ' ')
			j--;
		if (palabra[i] != aux[j] ){
			//cout << "false " << i << j << endl;
			palindromo = false;
			break;
		}
		j--;
	}

	if(palindromo){
		cout << "Es palindromo" << endl;
	}else{
		cout << "No es palindromo" << endl;
	}

}


	return 0;
}