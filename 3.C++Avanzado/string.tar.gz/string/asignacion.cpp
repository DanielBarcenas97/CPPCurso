#include <iostream>
#include <string>

using namespace std;

int main(){

	//Declaracion de cadenas:

	string cadena1 = "Hola mundo!";
	string cadena2("Adios mundo!");

	cout << "Cadena 1: " << cadena1 << endl << "Cadena 2: " << 
	cadena2 << endl << endl;

	//Asignacion de cadenas:

	cadena2 = cadena1;

	cout << "Cadena 1: " << cadena1 << endl << "Cadena 2: " << 
	cadena2 << endl << endl;

	cadena2 = 'H';

	cout << "Cadena 1: " << cadena1 << endl << "Cadena 2: " << 
	cadena2 << endl << endl;

	//Acceder a elementos del string:

	int posicion;

	cout << "Dame un numero: ";
	cin >> posicion;
	cout << "El caracter en la posicion " << posicion << 
	" de la cadena1 es: " << cadena1[posicion] << endl;

	//Comparacion entre cadenas:

	string cadena3,cadena4;

	cin.ignore();

	cout << "Dame la primer cadena: ";
	getline(cin,cadena3);
	cout << "Dame la segunda cadena: ";
	getline(cin,cadena4);

	if(cadena3 == cadena4){
		cout << "La primer cadena es igual a la segunda" << endl;
	}else if(cadena3 < cadena4){
		cout << "La primer cadena es menor que la segunda" << endl;
	}else if(cadena3 > cadena4){
		cout << "La primer cadena es mayor que la segunda" << endl;
	}



	return 0;
}