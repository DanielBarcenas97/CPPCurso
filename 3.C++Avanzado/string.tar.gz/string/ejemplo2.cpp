#include <iostream>
#include <string>

using namespace std;

int main(){

	string cadena1,cadena2;

	cout << "Dame una cadena: ";
	getline(cin,cadena1);
	cout << "Dame otra cadena: ";
	getline(cin,cadena2);

	cout << cadena1 << endl;
	cout << cadena2 << endl;

	cout << "El tamaño de la cadena 1 es: " << cadena1.length() << endl;

	//Concatenacion:
	//cadena1 += cadena2;

	cout << cadena1 << endl; 
	//Tamaño de una cadena:	
	cout << "El tamaño de la cadena 1 es: " << cadena1.length() << endl;

	//Subcadenas:

	string substr;

	cout << "Dame una subcadena: ";
	getline(cin,substr);

	//Para que funcione lo siguiente hay que comentar la linea 21 (posible pregunta)

	if(cadena1.find(substr) != string::npos){
		cout << "Subcadena encontrada en la cadena 1" << endl;
	}else if(cadena2.find(substr) != string::npos){
		cout << "Subcadena encontrada en la cadena 2" << endl;
	}else{
		cout << "Cadena no encontrada :'v" << endl;
	}

	cout<<cadena1.find_first_of(substr)<<endl; 
	//retorna la posición del caracter que aparezca primero de esos 3

	cout<<cadena1.find_last_of(substr)<<endl; 
	//retorna la posición del caracter que aparezca de último entre esos 3

	cout<<cadena1.find_first_not_of(substr)<<endl;
	//retorna la posición del primer caracter en str que sea diferente a todos los del argumento

	cout<<cadena1.find_last_not_of(substr)<<endl; 
	// retorna la posición del ultimo caracter en str que sea diferente de todos los del argumento

	//Obtener subcadenas:
	string cadena3 = "camara";
	cout << "Subcadena de la cadena 3: " << cadena3.substr(2,3) << endl;

	return 0;
}